package com.ovaltrack.backend.division.repository;

import java.util.Collection;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ovaltrack.backend.division.domain.DivisionCoach;

public interface DivisionCoachRepository extends JpaRepository<DivisionCoach, UUID> {

    @Query("SELECT dc FROM DivisionCoach dc WHERE dc.division.id = :divisionId AND dc.endDate IS NULL")
    Collection<DivisionCoach> findActiveDivisionCoachesByDivisionId(@Param("divisionId") UUID divisionId);

    @Query("""
            SELECT COUNT(dc) > 0
            FROM DivisionCoach dc 
            WHERE dc.division.id = :divisionId
            AND dc.person.id = :personId 
            AND dc.endDate IS NULL
        """)
    boolean existsActiveAssociation(@Param("divisionId") UUID divisionId,
            @Param("personId") UUID personId);

    @Query("SELECT dc FROM DivisionCoach dc JOIN FETCH dc.division d WHERE dc.person.id = :personId AND dc.endDate IS NULL")
    Collection<DivisionCoach> findActiveByPersonId(@Param("personId") UUID personId);

	@Query("""
            SELECT dc 
            FROM DivisionCoach dc 
            WHERE dc.division.id = :divisionId 
            AND dc.person.id = :personId
            ORDER BY startDate DESC
            """)
	Collection<DivisionCoach> findDivisionCoachesByDivisionIdAndPersonId(@Param("divisionId") UUID divisionId, @Param ("personId") UUID personId);

}