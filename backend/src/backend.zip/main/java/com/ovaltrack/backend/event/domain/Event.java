package com.ovaltrack.backend.event.domain;

import com.ovaltrack.backend.match.domain.Match;
import com.ovaltrack.backend.person.domain.Person;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "events",
       uniqueConstraints = {@UniqueConstraint(name = "uk_event_snapshot", columnNames = { "event_type_id", "match_id", "realTime" })})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Event {

    public static final String ORIGIN_POST_CAPTURE = "post_capture";

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @EqualsAndHashCode.Include
    private UUID id;

    @Column(name = "client_event_id", unique = true)
    private UUID clientEventId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_type_id", nullable = false)
    private EventType eventType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "match_id", nullable = false)
    private Match match;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "player_id")
    private Person player;

    @Enumerated(EnumType.STRING)
    @Column(name = "team_possession")
    private EventPossession teamPossession;

    private Integer matchTime;

    private Integer absoluteMatchTime;

    private LocalDateTime realTime;

    private Integer period;

    private String origin;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private Map<String, Object> attributes;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    private LocalDateTime synchronizedAt;

    private Boolean active;

    public String getEventTypeName() {
        return this.eventType != null && this.eventType.getName() != null ? this.eventType.getName() : "";
    }
}
